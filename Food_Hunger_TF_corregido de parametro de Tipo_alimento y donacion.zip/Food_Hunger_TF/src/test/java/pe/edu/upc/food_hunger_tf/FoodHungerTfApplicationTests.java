package pe.edu.upc.food_hunger_tf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodHungerTfApplicationTests {

	@Test
	void contextLoads() {
	}

}
