package pe.edu.upc.food_hunger_tf.dtos;

import lombok.Data;

@Data
public class Tipo_Alimento_DTO {
    private int id_TipoAlimento;
    private String nombre_TA;
    private String Descripcion_general;

}
