package pe.edu.upc.food_hunger_tf.dtos;

import lombok.Data;

@Data
public class Tipo_Donacion_DTO {
    private int idTipoDonacion;
    private String nombreTD;
}
