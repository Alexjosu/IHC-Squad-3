package pe.edu.upc.food_hunger_tf.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upc.food_hunger_tf.entities.Alimentos_donados_por_Donante;

public interface IAlimentos_donados_por_DonanteRepository extends JpaRepository<Alimentos_donados_por_Donante, Long> {

}
