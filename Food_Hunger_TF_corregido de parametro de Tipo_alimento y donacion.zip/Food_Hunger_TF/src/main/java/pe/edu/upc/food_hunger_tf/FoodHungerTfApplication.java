package pe.edu.upc.food_hunger_tf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodHungerTfApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodHungerTfApplication.class, args);
	}

}
